// Netlify Function: prayer request email delivery.
// Configure RESEND_API_KEY and PRAYER_FROM_EMAIL in Netlify environment variables.
// PRAYER_FROM_EMAIL must be an address on a domain verified with Resend.
exports.handler = async (event) => {
  const headers = { "Content-Type": "application/json", "Cache-Control": "no-store" };
  const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed." });
  if (!process.env.RESEND_API_KEY || !process.env.PRAYER_FROM_EMAIL) {
    return reply(503, { error: "Prayer email has not been configured by the ministry yet." });
  }
  let data;
  try { data = JSON.parse(event.body || "{}"); } catch { return reply(400, { error: "Invalid request." }); }
  // Honeypot field: silently accept bots without sending email.
  if (data.website) return reply(200, { ok: true });
  const name = typeof data.name === "string" ? data.name.trim().slice(0, 80) : "";
  const message = typeof data.message === "string" ? data.message.trim() : "";
  if (!message || message.length > 3000) return reply(400, { error: "Please enter a request of 1–3,000 characters." });
  const safeName = name.replace(/[<>]/g, "");
  const payload = {
    from: process.env.PRAYER_FROM_EMAIL,
    to: ["Inkarnationministry@gmail.com"],
    subject: "New Inkarnation prayer request",
    text: `A prayer request was submitted through the Inkarnation website.\n\nName: ${safeName || "Anonymous"}\n\nRequest:\n${message}\n\nPlease handle this message with care.`
  };
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) return reply(502, { error: "The email service could not deliver your request. Please try again later." });
    return reply(200, { ok: true });
  } catch {
    return reply(502, { error: "The email service is temporarily unavailable. Please try again later." });
  }
};
